# Release Notes

Last updated: 2/20/2015

  http://dev-registry.ctacdev.com
  http://dev-registry.ctacdev.com/search
  http://dev-registry.ctacdev.com/admin

  NOTE: All data in the system is test data.  It has no relation to government data, but demonstrates how items will relate to each other int he production system.

  All urls are fake, all information is randomly generated.

To be tested:
  Social media accounts can be created, edited, queried in swagger and the public search pages
  Mobile Apps can be created, edited, queried in swagger and the public search pages
  Galleries can be created, edited, queried in swagger and the public search pages
  Users can see/edit items only for their agencys.  Email on submissions is not currently functional.
  Admins can see and edit all data, as well as publish and unpublish data.
  To switch accounts, click username in top right and choose another under the "impersonate" header

Desired Feedback:

Not to be tested:
  Restoration of social media accounts / mobile apps to previous states
  Counts in the public app only reflect the total number for that facet in the system, not the number remaining based on currently available search terms.