Date::DATE_FORMATS[:human] = "%e %B %Y"
Date::DATE_FORMATS[:iso] = "%Y-%m-%d"

Time::DATE_FORMATS[:human] = "%e %B %Y"
Time::DATE_FORMATS[:iso] = "%Y-%m-%dT%H:%M:%S"
