Rails.application.config.assets.precompile += %w( public.css public.js swagger.css admin.css admin.js handlebars-3.0.0.js jquery.tokeninput.js)
