module Admin
  def self.table_name_prefix
    'admin_'
  end
end
