//= require jquery.sortable
//= require datatables
//= require datatables.bootstrap
//= require cocoon


function humanize(string)
{
    return string.charAt(0).toUpperCase() + string.slice(1);
}