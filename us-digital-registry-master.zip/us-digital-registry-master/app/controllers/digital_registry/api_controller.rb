class DigitalRegistry::ApiController < ApplicationController
  # rescue_from ActiveRecord::RecordNotFound, with: :record_not_found
  # # Use Mongoid::Errors::DocumentNotFound with mongoid

  # def record_not_found
  #   render json: {error: "not found"}, status: 404 
  # end
end 
