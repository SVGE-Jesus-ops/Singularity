class Public::HomeController < ApplicationController

  def index
    redirect_to "https://touchpoints.app.cloud.gov/registry"
  end

  def federalagencies
    redirect_to "https://touchpoints.app.cloud.gov/registry"
  end

  def developers
    redirect_to "https://touchpoints.app.cloud.gov/registry"
  end
end